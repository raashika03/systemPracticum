#include<bits/stdc++.h>
using namespace std;

    int main()  
    {  
        // initlialization

        int i, n, sum=0,count=0, y, quant, wt=0, tat=0, at[10], bt[10], temp[10],rt[10],st[10];  
        float avg_wt, avg_tat, avg_rt=0;  
        cout<<" Total number of process in the system: ";  
        cin>>n;  
        y = n; // Assign the number of process to variable y  
      
    // loop to enter the Arrival time and the Burst Time  

    for(i=0; i<n; i++)  
    {  
    cout<<"\nEnter the Arrival and Burst time of the Process "<<i+1<<'\n';  
    cout<<"Arrival time is: ";  
    cin>>at[i];  
    cout<<"Burst time is: "; 
    cin>>bt[i];  
    temp[i] = bt[i]; // storing brust time into temp array
    }  

    rt[0]=at[0];
    int r_sum=0;
    st[0]=at[0];

    for(i=1;i<n;i++)   //calculating response time
    {
        rt[i]=bt[i-1]-at[i]+r_sum;
        r_sum = r_sum+bt[i-1];
    }

    // Accept the Time qunat  
    cout<<"Enter the Time Quantum for the process: ";  
    cin>>quant;  

    for(i=1;i<n;i++)
         st[i] = st[i-1]+quant;
    // Display the process No, burst time, Turn Around Time and the waiting time  
    cout<<"\nProcess No \tBrust Time \tTAT \tWaiting Time \tResponse Time";  
    for(sum=0, i = 0; y!=0; )  
    {  
        if(temp[i] <= quant && temp[i] > 0) // define the conditions   
        {  
        sum = sum + temp[i];  
        temp[i] = 0;  
        count=1;  
        }     
        else if(temp[i] > 0)  
        {  
            temp[i] = temp[i] - quant;  
            sum = sum + quant;    
        }  
        if(temp[i]==0 && count==1)  
        {  
            y--; //decrement the process no.  
            cout<<"\n"<< i+1<<"\t\t"<<bt[i]<<"\t\t"<<sum-at[i]<<"\t\t "<<sum-at[i]-bt[i]<<"\t\t"<<rt[i];  
            wt = wt+sum-at[i]-bt[i];  
            tat = tat+sum-at[i];  
            count =0;     
        }  
        if(i==n-1)  
            i=0;  
        else if(at[i+1]<=sum) 
            i++;  
        else  
            i=0;  
    }  
    // represents the average waiting time and Turn Around time  
    avg_wt = wt * 1.0/n;  
    avg_tat = tat * 1.0/n;  
    for(i=0;i<n;i++)
        avg_rt+=rt[i];
    avg_rt = avg_rt * 1.0/n;
    cout<<'\n';
    cout<<"\n Average Turn Around Time: "<<avg_wt;  
    cout<<"\n Average Waiting Time: "<<avg_tat; 
    cout<<"\n Average Response Time: "<<avg_rt;  

    cout<<"\n Throughput: "<<1.0*(n/(sum-at[0]))<<"\n";
    }  