#include<bits/stdc++.h>
#include <pthread.h>
using namespace std;

// size of input array (second argument)
// number of threads (first argument)
// input array
int MAX,THREAD_MAX,*a;


//parameters to control the thread
struct tsk 
{
    int tsk_no;
    int tsk_low;
    int tsk_high;
};

void merge(int start, int mid, int end)
{
    int start2 = mid + 1;
 
    // If the direct merge is already sorted
    if (a[mid] <= a[start2]) {
        return;
    }
 
    // Two pointers to maintain start
    // of both arrays to merge
    while (start <= mid && start2 <= end) {
 
        // If element 1 is in right place
        if (a[start] <= a[start2]) {
            start++;
        }
        else {
            int value = a[start2];
            int index = start2;
 
            // Shift all the elements between element 1
            // element 2, right by 1.
            while (index != start) {
                a[index] = a[index - 1];
                index--;
            }
            a[start] = value;
 
            // Update all the pointers
            start++;
            mid++;
            start2++;
        }
    }
}
 
/* l is for left index and r is right index of the
   sub-array of arr to be sorted */
void merge_sort(int l, int r)
{
    if (l < r) {
 
        // Same as (l + r) / 2, but avoids overflow
        // for large l and r
        int m = l + (r - l) / 2;
 
        // Sort first and second halves
        merge_sort(l, m);
        merge_sort(m + 1, r);
 
        merge(l, m, r);
    }
}

// thread function for multi-threading
void * merge_sort123(void *arg)
{
    struct tsk *tsk = (struct tsk*)arg;
    int low;
    int high;

    // evaluating low and high
    low = tsk->tsk_low;
    high = tsk->tsk_high;

    // evaluating mid point
    int mid = low + (high - low) / 2;

    if (low < high) {
        merge_sort(low, mid);
        merge_sort(mid + 1, high);
        merge(low, mid, high);
    }

    return 0;
}

int main(int argc, char **argv)
{
    char *cp;
    struct tsk *tsk;

    MAX = 15;
    THREAD_MAX = 4;

    if(argc<=1)
    {
        cout<<"Enter size of array: ";
        cin>>MAX; 
        cout<<"Enter no. of threads: ";
        cin>>THREAD_MAX; 

    }
    else
    {
        int n_size = atoi(argv[2]);
        MAX = n_size;
        int th = atoi(argv[1]);
        THREAD_MAX = th;
    }

    // allocate the array
    a = new int[MAX];
    for (int i = 0; i < MAX; i++) 
        a[i] = rand() % 100;

    // Print the randomly generated integer-type array 
    printf("\nOriginal Array: ");
    for (int i = 0; i < MAX; ++i)
        cout<<a[i]<<" ";
    cout<<"\n";

    clock_t t1, t2; 
    t1 = clock(); 

    pthread_t threads[THREAD_MAX];
    struct tsk tsklist[THREAD_MAX];

    printf("\nTHREADS:%d\n", THREAD_MAX);

    int low = 0;

    for (int i = 0; i < THREAD_MAX; i++, low += MAX / THREAD_MAX) 
    {
        tsk = &tsklist[i];
        tsk->tsk_no = i;

        tsk->tsk_low = i * (MAX / THREAD_MAX);
        tsk->tsk_high = (i + 1) * (MAX / THREAD_MAX) - 1;
    }

    // creating threads
    for (int i = 0; i < THREAD_MAX; i++) {
        tsk = &tsklist[i];
        pthread_create(&threads[i], NULL, merge_sort123, tsk);
    }

    // joining all threads
    for (int i = 0; i < THREAD_MAX; i++)
        pthread_join(threads[i], NULL);

    // merging the final parts
    struct tsk *tskm = &tsklist[0];
    for (int i = 1; i < THREAD_MAX; i++) 
    {
        struct tsk *tsk = &tsklist[i];
        merge(tskm->tsk_low, tsk->tsk_low - 1, tsk->tsk_high);
    }

    t2 = clock(); 

    // Printing the sorted array
    printf("\nSorted array:");
    for (int i = 0; i < MAX; i++)
        cout<<a[i]<<" ";

    // time taken by merge sort in seconds 
    printf("\nTime taken: %f", ((t2-t1)/(double)CLOCKS_PER_SEC)); 
    printf(" seconds\n");

    return 0;
}