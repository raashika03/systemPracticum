Group_id: 2
Kalyani Kumari(b18063)
Rashika Rathi(b18081)

Language : C++17 (Gcc 9.1)


Q2:Round-Robin Scheduling
How to run?
step1- Go to the directory assign2_soln/q2_soln.
step2- run "make all" (without quotes)
step3- run "./q2" (without quotes)
step4- press "ctrl+c" for exiting.
Modules used:
#include <bits/stdc++.h>


Q3:Merge Sort using threads
How to run?
For parallel programming:
step1- Go to the directory assign2_soln/q3_soln.
step2- run "make all" (without quotes)
step3- run "./q3" (without quotes)
step4- press "ctrl+c" for exiting.
Modules used:
in file with cpp extension:
#include<bits/stdc++.h>
#include<pthread.h>

