#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#define num 5
#define left (s_num==0) ? 5 : s_num-1
#define right (s_num+1)%5

pthread_mutex_t mutex;
pthread_cond_t condition[num];

enum { THINKING, HUNGRY, EATING }state[5];
int std_num[5];

void *dinning(void *arg);
void grab_spoons(int s_num);
void putdown_spoons(int s_num);
void can_eat(int s_num);

void *dinning(void *arg)
{
  while(1) {
    int *s_num = arg;
    printf("Student %d: thinking.\n", *s_num + 1);
    sleep(1);
    grab_spoons(*s_num);
    putdown_spoons(*s_num);
  }
}

void grab_spoons(int s_num) 
{
  pthread_mutex_lock(&mutex);

  printf("Student %d: Waiting.\n", s_num + 1);
  state[s_num] = HUNGRY;
  can_eat(s_num);
  while (state[s_num] != EATING) 
    pthread_cond_wait(&condition[s_num], &mutex);

  pthread_mutex_unlock(&mutex);
}

void putdown_spoons(int s_num) 
{
  pthread_mutex_lock(&mutex);

  printf("Student %d: putdown the spoons\n", s_num + 1);
  state[s_num] = THINKING;
  can_eat(left);
  can_eat(right);

  pthread_mutex_unlock(&mutex);
}

void can_eat(int s_num) {
  if (state[s_num] == HUNGRY && state[left] != EATING && state[right] != EATING)
  {
    printf("Student %d: starts EATING.\n", s_num + 1);
    state[s_num] = EATING;
    sleep(20);
    pthread_cond_signal(&condition[s_num]);
  }
}

int main()
{
  
  pthread_t ph_thread[num];
  pthread_mutex_init(&mutex, NULL);

  for (int i = 0; i < 5; i++) 
  {
    pthread_cond_init(&condition[i], NULL);
    std_num[i] = i;
  }
// Creating threads
  for (int i = 0; i < 5; i++) 
  {
    pthread_create(&ph_thread[i], NULL, dinning, &std_num[i]);
    sleep(1);
  }
  // Joining threads
  for (int i = 0; i < 5; i++)
    pthread_join(ph_thread[i], NULL);

  // Clean the mutex 
  pthread_mutex_destroy(&mutex);
  for (int i = 0; i < 5; i++)
    pthread_cond_destroy(&condition[i]);

  return(0);
}



