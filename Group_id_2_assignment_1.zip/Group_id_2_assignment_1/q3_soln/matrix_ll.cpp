#include<bits/stdc++.h>
#include<pthread.h>
using namespace std;


//Each thread computes single element in the resultant matrix 
void *multiply(void* arg) 
{ 
	int *data = (int *)arg; 
	int k = 0, i = 0; 
	
	int x = data[0]; 
	for (i = 1; i <= x; i++) 
		k += data[i]*data[i+x]; 
	
	int *p = (int*)malloc(sizeof(int)); 
		*p = k; 
	
//Used to terminate a thread and the return value is passed as a pointer 
	pthread_exit(p); 
} 

//Driver code 
int main(int argc, char *argv[]) 
{ 
 	for(int m=1;m<=1;m++){
	int n=atoi(argv[m]),i,j,k,count = 0;
	int matA[n][n],matB[n][n]; 
	//printf( "You have entered n %d\n",n);

	// Initialising both matrices with random values
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)matA[i][j]=rand() % 10;
	for(i=0;i<n;i++) 
			for(j=0;j<n;j++)matB[i][j]=rand() % 10; 
	
	// printing both matrices	
	cout<<"Matrix A :- \n";	 
	for (i=0;i<n;i++){ 
		for(j=0;j<n;j++) 
			cout<<matA[i][j]<<" ";
		cout<<"\n";
	}
	cout<<"Matrix B :- \n"; 			 
	for (i=0;i<n;i++){ 
		for(j=0;j<n;j++) 
			cout<<matB[i][j]<<" ";
		cout<<"\n";
	}
	//declaring array of threads of size n*n		 
	pthread_t *threads= (pthread_t*)malloc((n*n)*sizeof(pthread_t));  
	int* data = NULL; 
	for(i=0;i<n;i++) 
		for(j=0;j<n;j++) 
			{ 	
			//storing row and column elements in data 
			data=new int[800]; 
			data[0]=n; 
			for(k=0;k<n;k++) data[k+1] = matA[i][k]; 
			for(k=0;k<n;k++) data[k+n+1] = matB[k][j]; 
			//creating threads 
				pthread_create(&threads[count++], NULL, multiply, (void*)(data)); 
					} 
	printf("RESULTANT MATRIX IS :- \n"); 
	auto start = chrono::high_resolution_clock::now();				
	for(i=0;i<n*n;i++) 
	{ 
	void *k; 	
	//Joining all threads and collecting return value 
	pthread_join(threads[i], &k); 		
	int *p = (int *)k; 
	printf("%d ",*p); 
	if ((i + 1) % n == 0) 
		cout<<"\n";
	} 
	auto end=chrono::high_resolution_clock::now(); 
    double time_taken=chrono::duration_cast<chrono::nanoseconds>(end - start).count(); 
    time_taken *= 1e-9; 
    cout <<"For n:"<<n<<" "<< "log2 of running time"<<fixed << log2(time_taken) << setprecision(9)<< "\n";}
return 0; 
} 
