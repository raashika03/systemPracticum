import matplotlib.pyplot as plt
import pandas as pd
datall = pd.read_csv('/home/rashikarathi/Desktop/6th_sem/sp/assign1_soln/q3_soln/data_ll.txt',sep=' ',header=None)
datall = pd.DataFrame(datall)
plt.xlim([5, 350]) 
xll = datall[0]
yll = datall[1]
plt.plot(xll, yll,'r--')
dataseq = pd.read_csv('/home/rashikarathi/Desktop/6th_sem/sp/assign1_soln/q3_soln/data_seq.txt',sep=' ',header=None)
dataseq = pd.DataFrame(dataseq)
xseq = dataseq[0]
yseq = dataseq[1]
plt.plot(xseq, yseq,'g--')
plt.xlabel('n : size of matrix')  
plt.ylabel('log base 2 of running time in seconds')  
plt.title("Comparison of execution time for sequential vs parallel") 
plt.legend(["parallel", "sequential"], loc ="lower right") 
plt.show()