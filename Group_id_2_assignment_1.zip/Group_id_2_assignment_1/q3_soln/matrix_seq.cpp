#include<bits/stdc++.h>
using namespace std;
int main(int argc, char *argv[]) 
{ 
 	for(int m=1;m<=1;m++){
	int n=atoi(argv[m]),i,j,k,count = 0;
	int matA[n][n],matB[n][n],res[n][n]; 
	//printf( "You have entered n %d\n",n);

	// Initialising both matrices with random values
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)matA[i][j]=rand() % 10;
	for(i=0;i<n;i++) 
			for(j=0;j<n;j++)matB[i][j]=rand() % 10; 
	
	// printing both matrices	
	cout<<"Matrix A :- \n";	 
	for (i=0;i<n;i++){ 
		for(j=0;j<n;j++) 
			cout<<matA[i][j]<<" ";
		cout<<"\n";
	}
	cout<<"Matrix B :- \n"; 			 
	for (i=0;i<n;i++){ 
		for(j=0;j<n;j++) 
			cout<<matB[i][j]<<" ";
		cout<<"\n";
	}
	auto start = chrono::high_resolution_clock::now(); 
	for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            res[i][j] = 0;
            for (k = 0; k < n; k++)
                res[i][j] += matA[i][k] * matB[k][j];
        }
    }
    cout<<"Resultant Matrix :- \n"; 			 
	for (i=0;i<n;i++){ 
		for(j=0;j<n;j++) 
			cout<<res[i][j]<<" ";
		cout<<"\n";
	}
	auto end=chrono::high_resolution_clock::now(); 
    double time_taken=chrono::duration_cast<chrono::nanoseconds>(end - start).count(); 
    time_taken *= 1e-9; 
    cout <<"For n:"<<n<<" "<< "log2 of running time"<<fixed << log2(time_taken) << setprecision(9)<< "\n";}
return 0; 
} 
