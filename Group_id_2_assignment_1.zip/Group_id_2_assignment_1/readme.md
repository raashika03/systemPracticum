Language : C++17 (Gcc 9.1)




Q1:Creating shell
How to run?
step1- Go to the directory assign1_soln/q1_soln.
step2- run "g++ myshell.cpp" (without quotes)
step3- run "./a.out" (without quotes) OR run "./a.out file.txt" (without quotes) and you are free to change the commands inside file.txt.
step4- You will get the shell, enter your commands.
step5- press "ctrl+c" for getiing out of the shell.
Modules used:
#include <bits/stdc++.h>
#include <unistd.h>//for chdir function
#include <sys/stat.h>
#include <dirent.h>


Q2:Dining students
How to run?
step1- Go to the directory assign1_soln/q2_soln.
step2- run "make all" (without quotes)
step3- run "./q2" (without quotes)
step4- press "ctrl+c" for exiting.
Modules used:
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>


Q3:Matrix Multiplication
How to run?
For parallel programming:
step1- Go to the directory assign1_soln/q3_soln.
step2- run "g++ matrix_ll.cpp -lpthread" (without quotes)
step3- run "./a.out n" (without quotes) where n is the size of the matrix
step4- you will get the result of matrix multiplication and the running time.
For sequential programming:
step1- Go to the directory assign1_soln/q3_soln.
step2- run "g++ matrix_seq.cpp" (without quotes)
step3- run "./a.out n" (without quotes) where n is the size of the matrix
step4- you will get the result of matrix multiplication and the running time.
Modules used:
in file with cpp extension:
#include<bits/stdc++.h>
#include<pthread.h>

in file with py extension for graph:
import matplotlib.pyplot as plt
import pandas as pd
