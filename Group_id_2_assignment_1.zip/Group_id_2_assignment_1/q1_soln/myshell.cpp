//Contributed by b18063(Kalyani) and b18081(Rashika)
#include <bits/stdc++.h>
#include <unistd.h>//for chdir function
#include <sys/stat.h>
#include <dirent.h>
using namespace std;

#define maxlen 100
int setenv(const char *envname, const char *envval, int overwrite);

string histarray[30];
int hindex=0;
bool ifHFull=false;
int DirExists(const char *path)
{
    struct stat stats;
    stat(path, &stats);
    if(S_ISDIR(stats.st_mode))return 1;
    return 0;
}
void parse(string str, string command[])
{
    istringstream ss(str);
    int i=0;
    do{
        ss >> command[i++];
    }while(ss);
}
void printDirectory()
{
    char cwd[200];
    getcwd(cwd, sizeof(cwd));
    cout<<cwd<<"/MyShell\n>>";
}
void appendToHistory(string command) {
    histarray[hindex++]=command;
    if(hindex==30){
        hindex=0;
        ifHFull=true;
    }
}

void executeCommand(string command[], char * envp[]){
    if(command[0] == "clr"){
        /*\033[H moves the cursor to the top left corner of the screen (ie, the first column of the first row in the screen).
\033[J clears the part of the screen from the cursor to the end of the screen.*/
        cout<<"\033[H\033[J";
    }
    else if(command[0]=="pause"){
        cout<<"Shell Paused\nPress [Enter] key to continue.\n";
        string enter;
        getline(cin,enter);
    }
    else if(command[0]=="help"){
        cout<<"This simple shell supports the following internal commands:\n";
        cout<<"clr - Clear the screen.\n";
        cout<<"pause - Pause operations of the shell until ‘Enter’ is pressed.\n";
        cout<<"help - Display User Manual\n";
        cout<<"quit - Quit the shell.\n";
        cout<<"history - Display the list of previously executed commands, even on shell restart.\n";
        cout<<"cd<directory> - Change the current default directory to <directory>.\n";
        cout<<"dir <directory> - List all the contents of directory <directory>\n";
        cout<<"environ - List all the environment strings of the current shell and the bash shell.\n";
        cout<<"echo <comment> - Display <comment> on the display.\n";
    }
    else if(command[0]=="quit"){
        exit(0);
    }
    else if(command[0]=="history"){
        if(!ifHFull)
            for(int i=0;i<hindex;i++)cout<<i <<" "<<histarray[i]<<"\n";
        else{
            int count=0;
            while(count<20)cout<<count<<" "<<histarray[(hindex+(count++))%20]<<"\n";
        }
    }
    else if(command[0]=="cd"){
        char *c = const_cast<char *>(command[1].c_str());
        if(command[1].size()==0)cout<<"Enter your directory to change to.\n";
        else if(!DirExists(c))cout<<"This directory doesn't exist.\n";
        chdir(c);//chdir() changes the current working directory to that specified in path.
        char buff[FILENAME_MAX];
        setenv("PWD", getcwd(buff, FILENAME_MAX), 1);
    }
    else if(command[0] == "dir"){
        DIR *dir = opendir(const_cast<char *>(command[1].c_str()));
        if(dir == NULL){
            perror("");return;//perror() function displays the description of the error 
        }
        struct dirent *ent;
        while((ent = readdir(dir)) != NULL)cout<<ent->d_name<<"\n";
        closedir(dir);
    }
    else if(command[0] == "environ")for(int i=0;envp[i]!=NULL;i++)cout<<"\n"<<envp[i];
    else if(command[0]=="echo"){
        int i=1;
        while(command[i].size()!=0)cout<<command[i++]<<" ";
    }
    else if(command[1].size()!=0){
        cout<<"Command not found\n";
        return;
    }
    else cout<<"Command not found\n";
}
int main(int argc, char *argv[], char *envp[])
{
    char cwd[200];
    string val=(string)getcwd(cwd,sizeof(cwd))+"/myshell";
    char *var = const_cast<char *>(val.c_str());
    setenv("SHELL",var,1);
    if(argc>1)
    {
        fstream newfile;//Stream class to both read and write from/to files
        newfile.open(argv[1],ios::in);
        if(newfile.is_open()){
            string tp;
            while(getline(newfile,tp)){
                string parsedArgs[maxlen];
                parse(tp,parsedArgs);
                appendToHistory(tp);
                executeCommand(parsedArgs,envp);
            }
            newfile.close();
        }
    }
    else{
        while(1)
        {
            string input,parsedArgs[maxlen];
            printDirectory();
            getline (cin, input);
            appendToHistory(input);
            parse(input,parsedArgs);
            executeCommand(parsedArgs,envp);
        }
    }
}
